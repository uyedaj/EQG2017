#define _MCMCGLMMCC_H
#include "MCMCglmm.h" 
#include <map>                  
#include <new>            
#include <iostream>
#include <limits>
using namespace std;

